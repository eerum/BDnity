SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Community Manager](
	[choiceDepartment] [varchar](20) NOT NULL,
	[choicePost] [text] NULL,
	[makePost] [text] NULL,
	[Like] [bigint] NULL,
	[postClip] [bit] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

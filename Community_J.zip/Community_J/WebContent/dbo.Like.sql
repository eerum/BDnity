SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Like](
	[postLike] [bigint] NOT NULL,
	[commentLike] [bigint] NOT NULL
) ON [PRIMARY]
GO

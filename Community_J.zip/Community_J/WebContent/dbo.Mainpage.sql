SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Mainpage](
	[CommunityPage] [sql_variant] NOT NULL,
	[SeatingPage] [sql_variant] NOT NULL
) ON [PRIMARY]
GO

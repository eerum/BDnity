SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Member](
	[memNumber] [int] NOT NULL,
	[memName] [varchar](10) NOT NULL,
	[memDepartment] [varchar](20) NOT NULL
) ON [PRIMARY]
GO

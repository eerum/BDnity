SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[makePost](
	[postTitle] [varchar](100) NOT NULL,
	[postVideo] [varchar](max) NULL,
	[postContent] [text] NOT NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[postClip](
	[postTitle] [varchar](100) NOT NULL,
	[postComment] [text] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

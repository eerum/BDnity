SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[SeatingManager](
	[SeatingImage] [image] NOT NULL,
	[choiceConvenienceStore] [bit] NULL,
	[choiceRestarea] [bit] NULL,
	[choiceCafe] [bit] NULL,
	[fullSeat] [bit] NOT NULL,
	[emptySeat] [bit] NOT NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

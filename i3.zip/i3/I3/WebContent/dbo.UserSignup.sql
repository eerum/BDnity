SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[UserSignup](
	[signupDepartment] [varchar](20) NOT NULL,
	[signupName] [varchar](10) NOT NULL,
	[signupNumber] [int] NOT NULL
) ON [PRIMARY]
GO

package DB;

import java.sql.*;

public class DBConnection {

        public static void main(String[] args) {

                String driver = "com.microsoft.sqlserver.jdbc.SQLServerDriver";

                String url = "jdbc:sqlserver://localhost:1433";

                String user = "sa";

                String password = "jiyoung0203";

                // 1. JDBC Driver 로딩

                try {

                        Class.forName(driver);

                        // 2. 데이터베이스 연결 (by url with username and password)

                        Connection con = DriverManager.getConnection(url, user, password);

                        // 3. Statement 객체 생성

                        Statement stmt = con.createStatement();

                        // 4. Query 실행 (using Statement, receive the ResultSet)

                        String qry = "use DBnity;  " + "select * from UserSignup ";

                        ResultSet rs = stmt.executeQuery(qry);

                        System.out.println("signupDepartment\signupName\signupNumber");

                        System.out.println(
                                        "===========================================================================");

                        // 5. ResultSet 객체를 통해 데이터 추출 (row by row)

                        while (rs.next()) {

                                String id = rs.getString("signupDepartment");

                                String name = rs.getString("signupName");

                                String pw = rs.getString("signupNumber");

                                System.out.print("\t" + id);

                                System.out.print(name);

                                System.out.println("\t" + pw);

                        }

                        // 6. 자원 반납

                        rs.close();

                        stmt.close();

                        con.close();

                } catch (ClassNotFoundException e) {

                        e.printStackTrace();

                } catch (SQLException e) {

                        e.printStackTrace();

                }

        }

}